$(document).ready(function() {
  console.log("JS Loaded");
  $.getJSON("javascript/code-test.json", function(json) {
   var jsonData = json;
    jsonData.sort(function(a, b){
     console.log("sorting ...");
     return b.apy - a.apy;
   });
   showData(jsonData);
  }) 
  .fail(function() {
   console.log( "error" );
  });
  function showData(json){
   $.each( json, function(i, json) {
    $("#rates-data").append( "<div id='data-box-"+i+"' class='rates-list"+i%2+"'></div>" );
    $("#data-box-"+i+"").append("<div class='name-box'>"+json.name+"</div><div class='apy-rate-box'>"+json.apy+"</div><div class='earnings-rate-box'>"+json.earnings+"</div>");
   });
  }
  $( "#modal-close" ).click(function() {
    $( "#modal" ).hide( "slow", function() {});
  });
  $( "#modal-login-button" ).click(function() {
    $( "#modal" ).hide( "fast", function() {});
  });
  $( "#login-button" ).click(function() {
    $( "#modal" ).show( "fast", function() {});
  });
 });